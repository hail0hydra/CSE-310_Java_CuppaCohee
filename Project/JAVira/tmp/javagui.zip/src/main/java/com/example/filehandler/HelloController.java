package com.example.filehandler;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class HelloController implements Initializable {
    FileChooser fc = new FileChooser();

    @FXML
    private Button check;

    @FXML
    private Button file;

    @FXML
    private TextArea txtview;

    @FXML
    private CheckBox box1;

    @FXML
    private CheckBox box2;

    @FXML
    void selectbox1(MouseEvent event) {
            if(box1.isSelected())
            {
                //method name for checkbox1
//                dumpJson();
            }

    }

    @FXML
    void selectbox2(MouseEvent event) {
            if(box2.isSelected())
            {
                //method name for checkbox2
//                logFile();
            }
    }
    @FXML
    void clickedOncheck(ActionEvent event) {

        //the method name for check button is checkVirus , and stored it in variable mal .

//        int mal = checkVirus();
//        //mal is checked for malicious or not
//        if(mal>0)
//        {
//            check.setOnAction(e -> Alertbox.display("Checking for the files" , "Oops! File is malicious!!!"));
                //passing the title and the message in the alertbox's display method
//        }
//        else
//        {
//            check.setOnAction(e -> Alertbox.display("Checking for the files" , "Yay! File is safe!!!"));
//        }
        Icon.setStageIcon(new Stage());
         
    }

    @FXML
    void getText(MouseEvent event)
    {
        //selecting file from system
        File selectedfile = fc.showOpenDialog(new Stage());
        if(selectedfile!=null)
        {
            //writes the absolute path in the text window
             txtview.appendText(selectedfile.getAbsolutePath());
        }

    }
    @FXML
    void clickedOnfile(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        fc.showOpenDialog(null);

    }
}
