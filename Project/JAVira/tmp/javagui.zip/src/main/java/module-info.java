module com.example.filehandler {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.filehandler to javafx.fxml;
    exports com.example.filehandler;
}